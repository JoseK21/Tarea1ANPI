from setuptools import setup, find_packages

setup(name='SolNE',
      version='0.1',
      description='Paquete computacional para metodos iterativos para encontrar raices',
      url='#',
      author='Jung Bak',
      author_email='bakkim05@gmail.com',
      license='MIT',
      packages=find_packages(),
      zip_safe=False)
